SELECT COUNT(*) AS count
FROM ducklings
WHERE color = 'yellow';
