SELECT name
FROM ducklings
ORDER BY age ASC, name ASC
LIMIT 1;
