SELECT name
FROM ducklings
ORDER BY age DESC, name ASC
LIMIT 1;
