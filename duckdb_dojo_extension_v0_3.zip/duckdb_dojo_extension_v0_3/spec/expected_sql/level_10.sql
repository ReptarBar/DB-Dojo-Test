SELECT name
FROM ducklings
WHERE color IN ('yellow', 'brown')
ORDER BY name ASC;
