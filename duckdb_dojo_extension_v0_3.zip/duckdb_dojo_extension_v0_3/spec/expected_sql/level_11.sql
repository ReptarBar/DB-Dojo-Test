SELECT name
FROM ducklings
WHERE name LIKE 'D%'
ORDER BY name ASC;
